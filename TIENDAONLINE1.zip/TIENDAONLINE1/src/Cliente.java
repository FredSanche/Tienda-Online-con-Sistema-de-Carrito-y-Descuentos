import java.util.ArrayList;
import java.util.List;

public class Cliente extends IDdescuento {
    private String nombre;
    private String correo;
    private List<Producto> carrito;

    public Cliente(String nombre, String correo) {
        this.nombre = nombre;
        this.correo = correo;
        this.carrito = new ArrayList<>();
    }

    public void agregarProductoAlCarrito(Producto producto) {
        carrito.add(producto);
    }

    public void mostrarCarrito() {
        for (Producto producto : carrito) {
            System.out.println(producto);
        }
    }

    public double calcularPrecio() {
        double total = 0;
        for (Producto producto : carrito) {
            total += producto.getPrecio();
        }
        return total;
    }

    public double aplicarDescuento() {
        double precioTotal = calcularPrecio();
        return aplicarDescuento(precioTotal);
    }
}

























//crea una clase llamada "Cliente", otra llamada "Producto", otra "IDdescuento" y la ultima "TiendaOnline"
//la clase "Producto" sera hija de la clase "Cliente" y llevaran una relacion de agregacion con la clase "Cliente", la clase "Producto" dentra los siguientes atributos : "nombre" sera private y de tipo String, "Precio" sera private de tipo double, "descripcion" sera private de tipo String, llevara su constructor con los atributos asignados, tendra toString y el getprecio.
//la clase "Cliente" sera hija de la clase "IDdescuento" y dentra una relacion de realizacion con la clase "IDdescuento", dentra los siguientes atributos : "nombre" sera private de tipo String, "correo" sera private de tipo String, "carrito" sera private de tipo list<Producto>, llevara su constructor con los atributos "nombre"  y  "correo", tendra un metodo llamado "agregarProductoAlCarrito" void, otro llamado "mostrarCarrito", otro llamado "calcularPrecio"  double, otro llamado "aplicarDescuento" double.