import java.util.Scanner;

public class TiendaOnline {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Cliente cliente = new Cliente("Fred", "frodriguezsanchez540.com");

        int opcion;
        do {
            System.out.println("Menú:");
            System.out.println("1. Agregar productos a su carrito de compras.");
            System.out.println("2. Visualizar su carrito de compras.");
            System.out.println("3. Realizar una compra y obtener el precio total con descuentos.");
            System.out.println("4. Salir");
            System.out.print("Elija una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine(); 

            switch (opcion) {
                case 1:
                    System.out.print("Nombre del producto: ");
                    String nombreProducto = scanner.nextLine();
                    System.out.print("Precio del producto: ");
                    double precioProducto = scanner.nextDouble();
                    scanner.nextLine(); 
                    System.out.print("Descripción del producto: ");
                    String descripcionProducto = scanner.nextLine();

                    Producto producto = new Producto(nombreProducto, precioProducto, descripcionProducto);
                    cliente.agregarProductoAlCarrito(producto);
                    System.out.println("Producto agregado al carrito.");
                    break;
                case 2:
                    System.out.println("Carrito del cliente:");
                    cliente.mostrarCarrito();
                    break;
                /* case 3:
                    double precioTotal = cliente.calcularPrecio();
                    double descuento = cliente.aplicarDescuento();
                    double precioConDescuento = precioTotal - descuento;
                    System.out.println("Precio total del carrito: " + precioTotal);
                    System.out.println("Descuento aplicado: " + descuento);
                    System.out.println("Precio con descuento: " + precioConDescuento);
                    break; */
                case 3:
                    double precioTotal = cliente.calcularPrecio();
                    double descuento = cliente.aplicarDescuento(); // Llamada directa al método sin pasar precioTotal
                    double precioConDescuento = precioTotal - descuento;
                    System.out.println("Precio total del carrito: " + precioTotal);
                    System.out.println("Descuento aplicado: " + descuento);
                    System.out.println("Precio con descuento: " + precioConDescuento);
                    break;
                
                case 4:
                    System.out.println("Saliendo de la tienda en línea. ¡Gracias por su Compra.!");
                    break;
                default:
                    System.out.println("Opción no válida. Intente de nuevo.");
                    break;
            }
        } while (opcion != 4);
        scanner.close();
    }
}
