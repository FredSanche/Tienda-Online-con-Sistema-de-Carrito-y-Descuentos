public class IDdescuento {
    public double aplicarDescuento(double precioTotal) {
        // Lógica de descuento: Descuento del 10% si el precio total es mayor o igual a $100
        if (precioTotal >= 100.0) {
            return precioTotal * 0.10;
        } else {
            return 0.0; // Sin descuento
        }
    }
}
